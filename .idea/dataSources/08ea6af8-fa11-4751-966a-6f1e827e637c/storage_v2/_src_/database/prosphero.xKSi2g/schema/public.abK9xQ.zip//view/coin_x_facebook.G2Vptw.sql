CREATE VIEW coin_x_facebook AS
  SELECT cryptocompare_coin_x_facebook.report_dt,
    coin.code AS coin_code,
    cryptocompare_coin_x_facebook.likes,
    cryptocompare_coin_x_facebook.talking_about,
    cryptocompare_coin_x_facebook.is_closed,
    cryptocompare_coin_x_facebook.link,
    cryptocompare_coin_x_facebook.points
   FROM (( SELECT (coin_x_facebook.valid_from_dttm)::date AS report_dt,
            coin_x_facebook.coin_id,
            coin_x_facebook.likes,
            coin_x_facebook.talking_about,
            coin_x_facebook.is_closed,
            coin_x_facebook.link,
            coin_x_facebook.points,
            row_number() OVER (PARTITION BY ((coin_x_facebook.valid_from_dttm)::date), coin_x_facebook.coin_id ORDER BY coin_x_facebook.valid_from_dttm DESC) AS rn
           FROM cryptocompare.coin_x_facebook
          WHERE (1 = 1)) cryptocompare_coin_x_facebook
     JOIN cryptocompare.coin ON ((cryptocompare_coin_x_facebook.coin_id = coin.id)))
  WHERE ((1 = 1) AND (cryptocompare_coin_x_facebook.rn = 1) AND (cryptocompare_coin_x_facebook.link IS NOT NULL));

