create view exchange_attendance as
  SELECT exchange_x_db_attendance.report_dt,
    exchange_x_db_attendance.domain,
    sum(exchange_x_db_attendance.organic_traffic) AS organic_traffic,
    sum(exchange_x_db_attendance.adwords_traffic) AS adwords_traffic
   FROM exchange_x_db_attendance
  GROUP BY exchange_x_db_attendance.report_dt, exchange_x_db_attendance.domain;

