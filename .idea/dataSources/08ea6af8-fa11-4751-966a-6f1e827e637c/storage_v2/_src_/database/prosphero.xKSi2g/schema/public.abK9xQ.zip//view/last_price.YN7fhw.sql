CREATE VIEW last_price AS
  SELECT t.valid_from_dt AS last_price_dttm,
    t.source_coin,
    t.target_coin,
    t.price
   FROM ( SELECT price.valid_from_dt,
            price.source_coin,
            price.target_coin,
            price.price,
            row_number() OVER (PARTITION BY price.source_coin, price.target_coin ORDER BY price.valid_from_dt DESC) AS rn
           FROM cryptocompare.price) t
  WHERE ((1 = 1) AND (t.rn = 1));

