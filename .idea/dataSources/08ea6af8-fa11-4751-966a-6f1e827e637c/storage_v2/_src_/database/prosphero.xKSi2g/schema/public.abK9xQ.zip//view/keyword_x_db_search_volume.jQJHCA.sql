CREATE VIEW keyword_x_db_search_volume AS
  SELECT semrush_keyword_search_volume.report_dt,
    semrush_keyword_search_volume.keyword,
    semrush_keyword_search_volume.database,
    semrush_keyword_search_volume.search_volume
   FROM ( SELECT (keyword_search_volume.report_dt)::date AS report_dt,
            keyword_search_volume.keyword,
            keyword_search_volume.database,
            keyword_search_volume.search_volume,
            row_number() OVER (PARTITION BY ((keyword_search_volume.report_dt)::date), keyword_search_volume.keyword, keyword_search_volume.database ORDER BY keyword_search_volume.valid_from_dttm DESC) AS rn
           FROM semrush.keyword_search_volume) semrush_keyword_search_volume
  WHERE ((1 = 1) AND (semrush_keyword_search_volume.rn = 1));

