create view coin_x_twitter as
  SELECT cryptocompare_coin_x_twitter.report_dt,
    coin.code AS coin_code,
    cryptocompare_coin_x_twitter.followers,
    cryptocompare_coin_x_twitter.following,
    cryptocompare_coin_x_twitter.favourites,
    cryptocompare_coin_x_twitter.statuses,
    cryptocompare_coin_x_twitter.points,
    cryptocompare_coin_x_twitter.lists,
    cryptocompare_coin_x_twitter.account_create_dt,
    cryptocompare_coin_x_twitter.account_url
   FROM (( SELECT (coin_x_twitter.valid_from_dttm)::date AS report_dt,
            coin_x_twitter.coin_id,
            coin_x_twitter.followers,
            coin_x_twitter.following,
            coin_x_twitter.favourites,
            coin_x_twitter.statuses,
            coin_x_twitter.points,
            coin_x_twitter.lists,
            (coin_x_twitter.account_create_dt)::date AS account_create_dt,
            coin_x_twitter.account_url,
            row_number() OVER (PARTITION BY ((coin_x_twitter.valid_from_dttm)::date), coin_x_twitter.coin_id ORDER BY coin_x_twitter.valid_from_dttm DESC) AS rn
           FROM cryptocompare.coin_x_twitter
          WHERE (1 = 1)) cryptocompare_coin_x_twitter
     JOIN cryptocompare.coin ON ((cryptocompare_coin_x_twitter.coin_id = coin.id)))
  WHERE ((1 = 1) AND (cryptocompare_coin_x_twitter.rn = 1) AND (cryptocompare_coin_x_twitter.followers IS NOT NULL));

