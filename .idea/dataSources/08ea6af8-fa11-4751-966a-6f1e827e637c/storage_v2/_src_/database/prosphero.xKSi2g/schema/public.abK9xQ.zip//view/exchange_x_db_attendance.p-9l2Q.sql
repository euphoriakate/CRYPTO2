CREATE VIEW exchange_x_db_attendance AS
  SELECT semrush_exchange_attendance.report_dt,
    semrush_exchange_attendance.country,
    semrush_exchange_attendance.domain,
    semrush_exchange_attendance.rank,
    semrush_exchange_attendance.organic_traffic,
    semrush_exchange_attendance.adwords_traffic
   FROM ( SELECT (exchange_attendance.report_dt)::date AS report_dt,
            exchange_attendance.country,
            exchange_attendance.domain,
            exchange_attendance.rank,
            exchange_attendance.organic_traffic,
            exchange_attendance.adwords_traffic,
            row_number() OVER (PARTITION BY exchange_attendance.report_dt, exchange_attendance.country, exchange_attendance.domain ORDER BY exchange_attendance.valid_from_dttm DESC) AS rn
           FROM semrush.exchange_attendance) semrush_exchange_attendance
  WHERE ((1 = 1) AND (semrush_exchange_attendance.rn = 1));

