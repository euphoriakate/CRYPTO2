CREATE VIEW coin_x_reddit AS
  SELECT cryptocompare_coin_x_reddit.report_dt,
    coin.code AS coin_code,
    cryptocompare_coin_x_reddit.subscribers,
    cryptocompare_coin_x_reddit.active_users,
    cryptocompare_coin_x_reddit.posts_per_day,
    cryptocompare_coin_x_reddit.posts_per_hour,
    cryptocompare_coin_x_reddit.comments_per_day,
    cryptocompare_coin_x_reddit.comments_per_hour,
    cryptocompare_coin_x_reddit.community_creation_dt,
    cryptocompare_coin_x_reddit.link,
    cryptocompare_coin_x_reddit.points
   FROM (( SELECT (coin_x_reddit.valid_from_dttm)::date AS report_dt,
            coin_x_reddit.coin_id,
            coin_x_reddit.subscribers,
            coin_x_reddit.active_users,
            coin_x_reddit.posts_per_day,
            coin_x_reddit.posts_per_hour,
            coin_x_reddit.comments_per_day,
            coin_x_reddit.comments_per_hour,
            (coin_x_reddit.community_creation_dt)::date AS community_creation_dt,
            coin_x_reddit.link,
            coin_x_reddit.points,
            row_number() OVER (PARTITION BY ((coin_x_reddit.valid_from_dttm)::date), coin_x_reddit.coin_id ORDER BY coin_x_reddit.valid_from_dttm DESC) AS rn
           FROM cryptocompare.coin_x_reddit
          WHERE (1 = 1)) cryptocompare_coin_x_reddit
     JOIN cryptocompare.coin ON ((cryptocompare_coin_x_reddit.coin_id = coin.id)))
  WHERE ((1 = 1) AND (cryptocompare_coin_x_reddit.rn = 1) AND (cryptocompare_coin_x_reddit.link IS NOT NULL));

