create view keyword_search_volume as
  SELECT keyword_x_db_search_volume.report_dt,
    keyword_x_db_search_volume.keyword,
    sum(keyword_x_db_search_volume.search_volume) AS search_volume
   FROM keyword_x_db_search_volume
  GROUP BY keyword_x_db_search_volume.report_dt, keyword_x_db_search_volume.keyword;

