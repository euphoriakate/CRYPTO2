create view exchange as
  SELECT exchange.exchange_name,
    exchange.source_coin,
    exchange.target_coin
   FROM cryptocompare.exchange
  WHERE ((1 = 1) AND (exchange.valid_from_dttm = ( SELECT max(exchange_1.valid_from_dttm) AS max
           FROM cryptocompare.exchange exchange_1)) AND ((exchange.source_coin)::text <> ''::text) AND ((exchange.target_coin)::text <> ''::text));

