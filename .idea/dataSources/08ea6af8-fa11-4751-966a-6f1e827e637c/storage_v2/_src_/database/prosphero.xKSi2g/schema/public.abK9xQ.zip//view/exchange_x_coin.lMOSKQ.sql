create view exchange_x_coin as
  SELECT t.date,
    t.exchange_name,
    t.source_coin,
    t.target_coin,
    t.market_cap,
    t.volume_24_hour,
    t.volume_24_hour_to,
    t.total_volume24h,
    t.total_volume_24h_to,
    t.price
   FROM ( SELECT date(exchange_x_coin.valid_from_dttm) AS date,
            exchange_x_coin.exchange_name,
            exchange_x_coin.source_coin,
            exchange_x_coin.target_coin,
            exchange_x_coin.market_cap,
            exchange_x_coin.volume_24_hour,
            exchange_x_coin.volume_24_hour_to,
            exchange_x_coin.total_volume24h,
            exchange_x_coin.total_volume_24h_to,
            exchange_x_coin.price,
            row_number() OVER (PARTITION BY exchange_x_coin.exchange_name, exchange_x_coin.source_coin, exchange_x_coin.target_coin, (date(exchange_x_coin.valid_from_dttm)) ORDER BY exchange_x_coin.valid_from_dttm) AS rn
           FROM cryptocompare.exchange_x_coin
          WHERE (1 = 1)) t
  WHERE ((1 = 1) AND (t.rn = 1));

